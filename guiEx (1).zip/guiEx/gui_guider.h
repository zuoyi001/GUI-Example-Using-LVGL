
#ifndef GUI_GUIDER_H
#define GUI_GUIDER_H
#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"
#include "font.h"

typedef struct
{
	lv_obj_t *screen;
	bool screen_del;
	lv_obj_t *screen_label_13;
	lv_obj_t *screen_label_8;
	lv_obj_t *screen_label_7;
	lv_obj_t *screen_label_temp;
	lv_obj_t *screen_label_humi;
	lv_obj_t *screen_label_temp_point;
	lv_obj_t *screen_label_humi_point;
	lv_obj_t *screen_label_5;
	lv_obj_t *screen_label_6;
	lv_obj_t *screen_img_1;
	lv_obj_t *screen_img_2;
	lv_obj_t *screen_label_9;
	lv_obj_t *screen_line_1;
	lv_obj_t *screen_line_2;
	lv_obj_t *screen_line_3;
	lv_obj_t *screen_label_temp_max;
	lv_obj_t *screen_label_temp_min;
	lv_obj_t *screen_label_humi_max;
	lv_obj_t *screen_label_humi_min;
	lv_obj_t *screen_label_time_scale;
	lv_obj_t *screen_line_5;
	lv_obj_t *screen_line_4;
	lv_obj_t *screen_line_7;
	lv_obj_t *screen_line_12;
	lv_obj_t *screen_img_3;
	lv_obj_t *screen_label_10;
	lv_obj_t *screen_label_11;
	lv_obj_t *screen_label_12;
	lv_obj_t *screen_line_8;
	lv_obj_t *screen_line_10;
	lv_obj_t *screen_line_11;
	lv_obj_t *screen_line_9;
	lv_obj_t *screen_img_4;
	lv_obj_t *screen_img_5;
}lv_ui;

void init_scr_del_flag(lv_ui *ui);
void setup_ui(lv_ui *ui);
extern lv_ui guider_ui;
void setup_scr_screen(lv_ui *ui);
LV_IMG_DECLARE(_aircon_30x28);
LV_IMG_DECLARE(_dehumidifier_25x31);
LV_IMG_DECLARE(_hygro_25x25);
LV_IMG_DECLARE(_heater_30x30);
LV_IMG_DECLARE(_temperature_25x25);

//###########################################################################################################
void lvgl_chart_sht30_init();
void lvgl_sht30_add_data(lv_timer_t * timer);

#define   CHART_POINT_COUNT 48
static lv_obj_t * chart_sht30;
static lv_chart_series_t * chart_sht30_temp_ser;
static lv_chart_series_t * chart_sht30_humi_ser;

uint8_t charIdx;

#ifdef __cplusplus
}
#endif
#endif
