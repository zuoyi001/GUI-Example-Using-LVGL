
#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"

//############################################################################################################
//
//############################################################################################################
void setup_scr_screen(lv_ui *ui){

	//Write codes screen
	ui->screen = lv_obj_create(NULL);
	lv_obj_set_scrollbar_mode(ui->screen, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_main_main_default
	static lv_style_t style_screen_main_main_default;
	if (style_screen_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_main_main_default);
	else
		lv_style_init(&style_screen_main_main_default);
	lv_style_set_bg_color(&style_screen_main_main_default, lv_color_make(0xb3, 0xb3, 0xb3));
	lv_style_set_bg_opa(&style_screen_main_main_default, 255);
	lv_obj_add_style(ui->screen, &style_screen_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_13
	ui->screen_label_13 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_13, 2, 2);
	lv_obj_set_size(ui->screen_label_13, 236, 39);
	lv_obj_set_scrollbar_mode(ui->screen_label_13, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_13, "");
	lv_label_set_long_mode(ui->screen_label_13, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_13_main_main_default
	static lv_style_t style_screen_label_13_main_main_default;
	if (style_screen_label_13_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_13_main_main_default);
	else
		lv_style_init(&style_screen_label_13_main_main_default);
	lv_style_set_radius(&style_screen_label_13_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_13_main_main_default, lv_color_make(0x25, 0x46, 0x58));
	lv_style_set_bg_grad_color(&style_screen_label_13_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_13_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_13_main_main_default, 255);
	lv_style_set_shadow_width(&style_screen_label_13_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_13_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_13_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_13_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_13_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_13_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_13_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_letter_space(&style_screen_label_13_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_13_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_13_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_13_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_13_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_13_main_main_default, 8);
	lv_style_set_pad_bottom(&style_screen_label_13_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_13, &style_screen_label_13_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_8
	ui->screen_label_8 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_8, 121, 42);
	lv_obj_set_size(ui->screen_label_8, 117, 80);
	lv_obj_set_scrollbar_mode(ui->screen_label_8, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_8, "");
	lv_label_set_long_mode(ui->screen_label_8, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_8_main_main_default
	static lv_style_t style_screen_label_8_main_main_default;
	if (style_screen_label_8_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_8_main_main_default);
	else
		lv_style_init(&style_screen_label_8_main_main_default);
	lv_style_set_radius(&style_screen_label_8_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_8_main_main_default, lv_color_make(0x25, 0x46, 0x58));
	lv_style_set_bg_grad_color(&style_screen_label_8_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_8_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_8_main_main_default, 255);
	lv_style_set_shadow_width(&style_screen_label_8_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_8_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_8_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_8_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_8_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_8_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_8_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_letter_space(&style_screen_label_8_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_8_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_8_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_8_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_8_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_8_main_main_default, 8);
	lv_style_set_pad_bottom(&style_screen_label_8_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_8, &style_screen_label_8_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_7
	ui->screen_label_7 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_7, 2, 42);
	lv_obj_set_size(ui->screen_label_7, 117, 80);
	lv_obj_set_scrollbar_mode(ui->screen_label_7, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_7, "");
	lv_label_set_long_mode(ui->screen_label_7, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_7_main_main_default
	static lv_style_t style_screen_label_7_main_main_default;
	if (style_screen_label_7_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_7_main_main_default);
	else
		lv_style_init(&style_screen_label_7_main_main_default);
	lv_style_set_radius(&style_screen_label_7_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_7_main_main_default, lv_color_make(0x25, 0x46, 0x58));
	lv_style_set_bg_grad_color(&style_screen_label_7_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_7_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_7_main_main_default, 255);
	lv_style_set_shadow_width(&style_screen_label_7_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_7_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_7_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_7_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_7_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_7_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_7_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_letter_space(&style_screen_label_7_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_7_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_7_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_7_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_7_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_7_main_main_default, 8);
	lv_style_set_pad_bottom(&style_screen_label_7_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_7, &style_screen_label_7_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_temp
	ui->screen_label_temp = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_temp, 2, 75);
	lv_obj_set_size(ui->screen_label_temp, 88, 44);
	lv_obj_set_scrollbar_mode(ui->screen_label_temp, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_temp, "32");
	lv_label_set_long_mode(ui->screen_label_temp, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_temp_main_main_default
	static lv_style_t style_screen_label_temp_main_main_default;
	if (style_screen_label_temp_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_temp_main_main_default);
	else
		lv_style_init(&style_screen_label_temp_main_main_default);
	lv_style_set_radius(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_temp_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_temp_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_temp_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_temp_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_temp_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_temp_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_temp_main_main_default, &lv_font_arial_48);
	lv_style_set_text_letter_space(&style_screen_label_temp_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_temp_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_temp_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_temp_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_temp, &style_screen_label_temp_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_humi
	ui->screen_label_humi = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_humi, 124, 75);
	lv_obj_set_size(ui->screen_label_humi, 87, 40);
	lv_obj_set_scrollbar_mode(ui->screen_label_humi, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_humi, "78");
	lv_label_set_long_mode(ui->screen_label_humi, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_humi_main_main_default
	static lv_style_t style_screen_label_humi_main_main_default;
	if (style_screen_label_humi_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_humi_main_main_default);
	else
		lv_style_init(&style_screen_label_humi_main_main_default);
	lv_style_set_radius(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_humi_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_humi_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_humi_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_humi_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_humi_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_humi_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_humi_main_main_default, &lv_font_arial_48);
	lv_style_set_text_letter_space(&style_screen_label_humi_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_humi_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_humi_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_humi_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_humi, &style_screen_label_humi_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_temp_point
	ui->screen_label_temp_point = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_temp_point, 86, 90);
	lv_obj_set_size(ui->screen_label_temp_point, 31, 22);
	lv_obj_set_scrollbar_mode(ui->screen_label_temp_point, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_temp_point, ".5");
	lv_label_set_long_mode(ui->screen_label_temp_point, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_temp_point_main_main_default
	static lv_style_t style_screen_label_temp_point_main_main_default;
	if (style_screen_label_temp_point_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_temp_point_main_main_default);
	else
		lv_style_init(&style_screen_label_temp_point_main_main_default);
	lv_style_set_radius(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_temp_point_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_temp_point_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_temp_point_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_temp_point_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_temp_point_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_temp_point_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_temp_point_main_main_default, &lv_font_arial_26);
	lv_style_set_text_letter_space(&style_screen_label_temp_point_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_temp_point_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_temp_point_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_temp_point_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_temp_point, &style_screen_label_temp_point_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_humi_point
	ui->screen_label_humi_point = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_humi_point, 204, 90);
	lv_obj_set_size(ui->screen_label_humi_point, 30, 23);
	lv_obj_set_scrollbar_mode(ui->screen_label_humi_point, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_humi_point, ".5");
	lv_label_set_long_mode(ui->screen_label_humi_point, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_humi_point_main_main_default
	static lv_style_t style_screen_label_humi_point_main_main_default;
	if (style_screen_label_humi_point_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_humi_point_main_main_default);
	else
		lv_style_init(&style_screen_label_humi_point_main_main_default);
	lv_style_set_radius(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_humi_point_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_humi_point_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_humi_point_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_humi_point_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_humi_point_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_humi_point_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_humi_point_main_main_default, &lv_font_arial_26);
	lv_style_set_text_letter_space(&style_screen_label_humi_point_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_humi_point_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_humi_point_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_humi_point_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_humi_point, &style_screen_label_humi_point_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_5
	ui->screen_label_5 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_5, 88, 70);
	lv_obj_set_size(ui->screen_label_5, 27, 15);
	lv_obj_set_scrollbar_mode(ui->screen_label_5, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_5, "°C");
	lv_label_set_long_mode(ui->screen_label_5, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_5_main_main_default
	static lv_style_t style_screen_label_5_main_main_default;
	if (style_screen_label_5_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_5_main_main_default);
	else
		lv_style_init(&style_screen_label_5_main_main_default);
	lv_style_set_radius(&style_screen_label_5_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_5_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_5_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_5_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_5_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_5_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_5_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_5_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_5_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_5_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_5_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_5_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_5_main_main_default, &lv_font_arial_18);
	lv_style_set_text_letter_space(&style_screen_label_5_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_5_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_5_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_5_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_5_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_5_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_5_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_5, &style_screen_label_5_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_6
	ui->screen_label_6 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_6, 210, 70);
	lv_obj_set_size(ui->screen_label_6, 23, 16);
	lv_obj_set_scrollbar_mode(ui->screen_label_6, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_6, "%");
	lv_label_set_long_mode(ui->screen_label_6, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_6_main_main_default
	static lv_style_t style_screen_label_6_main_main_default;
	if (style_screen_label_6_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_6_main_main_default);
	else
		lv_style_init(&style_screen_label_6_main_main_default);
	lv_style_set_radius(&style_screen_label_6_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_6_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_6_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_6_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_6_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_6_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_6_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_6_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_6_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_6_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_6_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_6_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_6_main_main_default, &lv_font_arial_18);
	lv_style_set_text_letter_space(&style_screen_label_6_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_6_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_6_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_6_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_6_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_6_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_6_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_6, &style_screen_label_6_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_img_1
	ui->screen_img_1 = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_1, 10, 6);
	lv_obj_set_size(ui->screen_img_1, 30, 28);
	lv_obj_set_scrollbar_mode(ui->screen_img_1, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_1_main_main_default
	static lv_style_t style_screen_img_1_main_main_default;
	if (style_screen_img_1_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_img_1_main_main_default);
	else
		lv_style_init(&style_screen_img_1_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_1_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_1_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_1, &style_screen_img_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_1, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_1,&_aircon_30x28);
	lv_img_set_pivot(ui->screen_img_1, 50,50);
	lv_img_set_angle(ui->screen_img_1, 0);

	//Write codes screen_img_2
	ui->screen_img_2 = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_2, 170, 5);
	lv_obj_set_size(ui->screen_img_2, 25, 31);
	lv_obj_set_scrollbar_mode(ui->screen_img_2, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_2_main_main_default
	static lv_style_t style_screen_img_2_main_main_default;
	if (style_screen_img_2_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_img_2_main_main_default);
	else
		lv_style_init(&style_screen_img_2_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_2_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_2_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_2_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_2, &style_screen_img_2_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_2, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_2,&_dehumidifier_25x31);
	lv_img_set_pivot(ui->screen_img_2, 50,50);
	lv_img_set_angle(ui->screen_img_2, 0);

	//Write codes screen_label_9
	ui->screen_label_9 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_9, 2, 124);
	lv_obj_set_size(ui->screen_label_9, 236, 114);
	lv_obj_set_scrollbar_mode(ui->screen_label_9, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_9, "");
	lv_label_set_long_mode(ui->screen_label_9, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_9_main_main_default
	static lv_style_t style_screen_label_9_main_main_default;
	if (style_screen_label_9_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_9_main_main_default);
	else
		lv_style_init(&style_screen_label_9_main_main_default);
	lv_style_set_radius(&style_screen_label_9_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_9_main_main_default, lv_color_make(0x25, 0x46, 0x58));
	lv_style_set_bg_grad_color(&style_screen_label_9_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_9_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_9_main_main_default, 255);
	lv_style_set_shadow_width(&style_screen_label_9_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_9_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_9_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_9_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_9_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_9_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_9_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_letter_space(&style_screen_label_9_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_9_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_9_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_9_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_9_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_9_main_main_default, 8);
	lv_style_set_pad_bottom(&style_screen_label_9_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_9, &style_screen_label_9_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_line_1
	ui->screen_line_1 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_1, 21, 110);
	lv_obj_set_size(ui->screen_line_1, 60, 1);
	lv_obj_set_scrollbar_mode(ui->screen_line_1, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_1_main_main_default
	static lv_style_t style_screen_line_1_main_main_default;
	if (style_screen_line_1_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_1_main_main_default);
	else
		lv_style_init(&style_screen_line_1_main_main_default);
	lv_style_set_line_color(&style_screen_line_1_main_main_default, lv_color_make(0x75, 0x75, 0x75));
	lv_style_set_line_width(&style_screen_line_1_main_main_default, 2);
	lv_style_set_line_rounded(&style_screen_line_1_main_main_default, true);
	lv_obj_add_style(ui->screen_line_1, &style_screen_line_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_1[] ={{0, 0},{60, 60},};
	lv_line_set_points(ui->screen_line_1,screen_line_1,2);

	//Write codes screen_line_2
	ui->screen_line_2 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_2, 35, 60);
	lv_obj_set_size(ui->screen_line_2, 80, 1);
	lv_obj_set_scrollbar_mode(ui->screen_line_2, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_2_main_main_default
	static lv_style_t style_screen_line_2_main_main_default;
	if (style_screen_line_2_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_2_main_main_default);
	else
		lv_style_init(&style_screen_line_2_main_main_default);
	lv_style_set_line_color(&style_screen_line_2_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_line_width(&style_screen_line_2_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_2_main_main_default, true);
	lv_obj_add_style(ui->screen_line_2, &style_screen_line_2_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_2[] ={{0, 0},{100, 0},};
	lv_line_set_points(ui->screen_line_2,screen_line_2,2);

	//Write codes screen_line_3
	ui->screen_line_3 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_3, 155, 60);
	lv_obj_set_size(ui->screen_line_3, 80, 1);
	lv_obj_set_scrollbar_mode(ui->screen_line_3, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_3_main_main_default
	static lv_style_t style_screen_line_3_main_main_default;
	if (style_screen_line_3_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_3_main_main_default);
	else
		lv_style_init(&style_screen_line_3_main_main_default);
	lv_style_set_line_color(&style_screen_line_3_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_line_width(&style_screen_line_3_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_3_main_main_default, true);
	lv_obj_add_style(ui->screen_line_3, &style_screen_line_3_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_3[] ={{0, 0},{100, 0},};
	lv_line_set_points(ui->screen_line_3,screen_line_3,2);

	//Write codes screen_label_temp_max
	ui->screen_label_temp_max = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_temp_max, 2, 130);
	lv_obj_set_size(ui->screen_label_temp_max, 28, 12);
	lv_obj_set_scrollbar_mode(ui->screen_label_temp_max, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_temp_max, "35");
	lv_label_set_long_mode(ui->screen_label_temp_max, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_temp_max_main_main_default
	static lv_style_t style_screen_label_temp_max_main_main_default;
	if (style_screen_label_temp_max_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_temp_max_main_main_default);
	else
		lv_style_init(&style_screen_label_temp_max_main_main_default);
	lv_style_set_radius(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_temp_max_main_main_default, lv_color_make(0xff, 0xff, 0x00));
	lv_style_set_bg_grad_color(&style_screen_label_temp_max_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_temp_max_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_temp_max_main_main_default, 255);
	lv_style_set_shadow_width(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_temp_max_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_temp_max_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_temp_max_main_main_default, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_temp_max_main_main_default, &lv_font_arial_12);
	lv_style_set_text_letter_space(&style_screen_label_temp_max_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_temp_max_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_temp_max_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_temp_max_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_temp_max, &style_screen_label_temp_max_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_temp_min
	ui->screen_label_temp_min = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_temp_min, 2, 210);
	lv_obj_set_size(ui->screen_label_temp_min, 27, 12);
	lv_obj_set_scrollbar_mode(ui->screen_label_temp_min, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_temp_min, "28");
	lv_label_set_long_mode(ui->screen_label_temp_min, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_temp_min_main_main_default
	static lv_style_t style_screen_label_temp_min_main_main_default;
	if (style_screen_label_temp_min_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_temp_min_main_main_default);
	else
		lv_style_init(&style_screen_label_temp_min_main_main_default);
	lv_style_set_radius(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_temp_min_main_main_default, lv_color_make(0xff, 0xff, 0x00));
	lv_style_set_bg_grad_color(&style_screen_label_temp_min_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_temp_min_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_temp_min_main_main_default, 255);
	lv_style_set_shadow_width(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_temp_min_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_temp_min_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_temp_min_main_main_default, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_temp_min_main_main_default, &lv_font_arial_12);
	lv_style_set_text_letter_space(&style_screen_label_temp_min_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_temp_min_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_temp_min_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_temp_min_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_temp_min, &style_screen_label_temp_min_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_humi_max
	ui->screen_label_humi_max = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_humi_max, 217, 130);
	lv_obj_set_size(ui->screen_label_humi_max, 20, 12);
	lv_obj_set_scrollbar_mode(ui->screen_label_humi_max, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_humi_max, "67");
	lv_label_set_long_mode(ui->screen_label_humi_max, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_humi_max_main_main_default
	static lv_style_t style_screen_label_humi_max_main_main_default;
	if (style_screen_label_humi_max_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_humi_max_main_main_default);
	else
		lv_style_init(&style_screen_label_humi_max_main_main_default);
	lv_style_set_radius(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_humi_max_main_main_default, lv_color_make(0x5c, 0x89, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_humi_max_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_humi_max_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_humi_max_main_main_default, 255);
	lv_style_set_shadow_width(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_humi_max_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_humi_max_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_humi_max_main_main_default, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_humi_max_main_main_default, &lv_font_arial_12);
	lv_style_set_text_letter_space(&style_screen_label_humi_max_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_humi_max_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_humi_max_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_humi_max_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_humi_max, &style_screen_label_humi_max_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_humi_min
	ui->screen_label_humi_min = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_humi_min, 217, 213);
	lv_obj_set_size(ui->screen_label_humi_min, 20, 12);
	lv_obj_set_scrollbar_mode(ui->screen_label_humi_min, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_humi_min, "51");
	lv_label_set_long_mode(ui->screen_label_humi_min, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_humi_min_main_main_default
	static lv_style_t style_screen_label_humi_min_main_main_default;
	if (style_screen_label_humi_min_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_humi_min_main_main_default);
	else
		lv_style_init(&style_screen_label_humi_min_main_main_default);
	lv_style_set_radius(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_humi_min_main_main_default, lv_color_make(0x5c, 0x89, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_humi_min_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_humi_min_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_humi_min_main_main_default, 255);
	lv_style_set_shadow_width(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_humi_min_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_humi_min_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_humi_min_main_main_default, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_humi_min_main_main_default, &lv_font_arial_12);
	lv_style_set_text_letter_space(&style_screen_label_humi_min_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_humi_min_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_humi_min_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_humi_min_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_humi_min, &style_screen_label_humi_min_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_time_scale
	ui->screen_label_time_scale = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_time_scale, 70, 221);
	lv_obj_set_size(ui->screen_label_time_scale, 140, 12);
	lv_obj_set_scrollbar_mode(ui->screen_label_time_scale, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_time_scale, "04        12        20");
	lv_label_set_long_mode(ui->screen_label_time_scale, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_time_scale_main_main_default
	static lv_style_t style_screen_label_time_scale_main_main_default;
	if (style_screen_label_time_scale_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_time_scale_main_main_default);
	else
		lv_style_init(&style_screen_label_time_scale_main_main_default);
	lv_style_set_radius(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_time_scale_main_main_default, lv_color_make(0x5c, 0x89, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_time_scale_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_time_scale_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_time_scale_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_time_scale_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_time_scale_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_time_scale_main_main_default, &lv_font_arial_12);
	lv_style_set_text_letter_space(&style_screen_label_time_scale_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_time_scale_main_main_default, LV_TEXT_ALIGN_RIGHT);
	lv_style_set_pad_left(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_time_scale_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_time_scale_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_time_scale, &style_screen_label_time_scale_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_line_5
	ui->screen_line_5 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_5, 30, 220);
	lv_obj_set_size(ui->screen_line_5, 185, 1);
	lv_obj_set_scrollbar_mode(ui->screen_line_5, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_5_main_main_default
	static lv_style_t style_screen_line_5_main_main_default;
	if (style_screen_line_5_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_5_main_main_default);
	else
		lv_style_init(&style_screen_line_5_main_main_default);
	lv_style_set_line_color(&style_screen_line_5_main_main_default, lv_color_make(0x40, 0x71, 0x89));
	lv_style_set_line_width(&style_screen_line_5_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_5_main_main_default, true);
	lv_obj_add_style(ui->screen_line_5, &style_screen_line_5_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_5[] ={{0, 0},{200, 0},};
	lv_line_set_points(ui->screen_line_5,screen_line_5,2);

	//Write codes screen_line_4
	ui->screen_line_4 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_4, 30, 160);
	lv_obj_set_size(ui->screen_line_4, 185, 1);
	lv_obj_set_scrollbar_mode(ui->screen_line_4, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_4_main_main_default
	static lv_style_t style_screen_line_4_main_main_default;
	if (style_screen_line_4_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_4_main_main_default);
	else
		lv_style_init(&style_screen_line_4_main_main_default);
	lv_style_set_line_color(&style_screen_line_4_main_main_default, lv_color_make(0x40, 0x71, 0x89));
	lv_style_set_line_width(&style_screen_line_4_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_4_main_main_default, true);
	lv_obj_add_style(ui->screen_line_4, &style_screen_line_4_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_4[] ={{0, 0},{200, 0},};
	lv_line_set_points(ui->screen_line_4,screen_line_4,2);

	//Write codes screen_line_7
	ui->screen_line_7 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_7, 30, 190);
	lv_obj_set_size(ui->screen_line_7, 185, 1);
	lv_obj_set_scrollbar_mode(ui->screen_line_7, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_7_main_main_default
	static lv_style_t style_screen_line_7_main_main_default;
	if (style_screen_line_7_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_7_main_main_default);
	else
		lv_style_init(&style_screen_line_7_main_main_default);
	lv_style_set_line_color(&style_screen_line_7_main_main_default, lv_color_make(0x40, 0x71, 0x89));
	lv_style_set_line_width(&style_screen_line_7_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_7_main_main_default, true);
	lv_obj_add_style(ui->screen_line_7, &style_screen_line_7_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_7[] ={{0, 0},{200, 0},};
	lv_line_set_points(ui->screen_line_7,screen_line_7,2);

	//Write codes screen_line_12
	ui->screen_line_12 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_12, 30, 130);
	lv_obj_set_size(ui->screen_line_12, 185, 1);
	lv_obj_set_scrollbar_mode(ui->screen_line_12, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_12_main_main_default
	static lv_style_t style_screen_line_12_main_main_default;
	if (style_screen_line_12_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_12_main_main_default);
	else
		lv_style_init(&style_screen_line_12_main_main_default);
	lv_style_set_line_color(&style_screen_line_12_main_main_default, lv_color_make(0x40, 0x71, 0x89));
	lv_style_set_line_width(&style_screen_line_12_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_12_main_main_default, true);
	lv_obj_add_style(ui->screen_line_12, &style_screen_line_12_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_12[] ={{0, 0},{200, 0},};
	lv_line_set_points(ui->screen_line_12,screen_line_12,2);

	//Write codes screen_img_3
	ui->screen_img_3 = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_3, 90, 5);
	lv_obj_set_size(ui->screen_img_3, 30, 30);
	lv_obj_set_scrollbar_mode(ui->screen_img_3, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_3_main_main_default
	static lv_style_t style_screen_img_3_main_main_default;
	if (style_screen_img_3_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_img_3_main_main_default);
	else
		lv_style_init(&style_screen_img_3_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_3_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_3_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_3_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_3, &style_screen_img_3_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_3, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_3,&_heater_30x30);
	lv_img_set_pivot(ui->screen_img_3, 50,50);
	lv_img_set_angle(ui->screen_img_3, 0);

	//Write codes screen_label_10
	ui->screen_label_10 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_10, 45, 15);
	lv_obj_set_size(ui->screen_label_10, 27, 15);
	lv_obj_set_scrollbar_mode(ui->screen_label_10, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_10, "28");
	lv_label_set_long_mode(ui->screen_label_10, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_10_main_main_default
	static lv_style_t style_screen_label_10_main_main_default;
	if (style_screen_label_10_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_10_main_main_default);
	else
		lv_style_init(&style_screen_label_10_main_main_default);
	lv_style_set_radius(&style_screen_label_10_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_10_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_10_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_10_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_10_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_10_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_10_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_10_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_10_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_10_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_10_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_10_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_10_main_main_default, &lv_font_arial_16);
	lv_style_set_text_letter_space(&style_screen_label_10_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_10_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_10_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_10_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_10_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_10_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_10_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_10, &style_screen_label_10_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_11
	ui->screen_label_11 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_11, 125, 15);
	lv_obj_set_size(ui->screen_label_11, 27, 15);
	lv_obj_set_scrollbar_mode(ui->screen_label_11, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_11, "20");
	lv_label_set_long_mode(ui->screen_label_11, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_11_main_main_default
	static lv_style_t style_screen_label_11_main_main_default;
	if (style_screen_label_11_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_11_main_main_default);
	else
		lv_style_init(&style_screen_label_11_main_main_default);
	lv_style_set_radius(&style_screen_label_11_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_11_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_11_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_11_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_11_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_11_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_11_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_11_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_11_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_11_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_11_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_11_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_11_main_main_default, &lv_font_arial_16);
	lv_style_set_text_letter_space(&style_screen_label_11_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_11_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_11_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_11_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_11_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_11_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_11_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_11, &style_screen_label_11_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_12
	ui->screen_label_12 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_12, 200, 15);
	lv_obj_set_size(ui->screen_label_12, 27, 15);
	lv_obj_set_scrollbar_mode(ui->screen_label_12, LV_SCROLLBAR_MODE_OFF);
	lv_label_set_text(ui->screen_label_12, "75");
	lv_label_set_long_mode(ui->screen_label_12, LV_LABEL_LONG_WRAP);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_12_main_main_default
	static lv_style_t style_screen_label_12_main_main_default;
	if (style_screen_label_12_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_label_12_main_main_default);
	else
		lv_style_init(&style_screen_label_12_main_main_default);
	lv_style_set_radius(&style_screen_label_12_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_12_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_12_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_12_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_label_12_main_main_default, 0);
	lv_style_set_shadow_width(&style_screen_label_12_main_main_default, 0);
	lv_style_set_shadow_color(&style_screen_label_12_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_label_12_main_main_default, 255);
	lv_style_set_shadow_spread(&style_screen_label_12_main_main_default, 0);
	lv_style_set_shadow_ofs_x(&style_screen_label_12_main_main_default, 0);
	lv_style_set_shadow_ofs_y(&style_screen_label_12_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_12_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_text_font(&style_screen_label_12_main_main_default, &lv_font_arial_16);
	lv_style_set_text_letter_space(&style_screen_label_12_main_main_default, 2);
	lv_style_set_text_line_space(&style_screen_label_12_main_main_default, 0);
	lv_style_set_text_align(&style_screen_label_12_main_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_left(&style_screen_label_12_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_12_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_12_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_12_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_12, &style_screen_label_12_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_line_8
	ui->screen_line_8 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_8, 30, 130);
	lv_obj_set_size(ui->screen_line_8, 1, 90);
	lv_obj_set_scrollbar_mode(ui->screen_line_8, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_8_main_main_default
	static lv_style_t style_screen_line_8_main_main_default;
	if (style_screen_line_8_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_8_main_main_default);
	else
		lv_style_init(&style_screen_line_8_main_main_default);
	lv_style_set_line_color(&style_screen_line_8_main_main_default, lv_color_make(0x40, 0x71, 0x89));
	lv_style_set_line_width(&style_screen_line_8_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_8_main_main_default, true);
	lv_obj_add_style(ui->screen_line_8, &style_screen_line_8_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_8[] ={{0, 0},{0, 140},};
	lv_line_set_points(ui->screen_line_8,screen_line_8,2);

	//Write codes screen_line_10
	ui->screen_line_10 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_10, 92, 130);
	lv_obj_set_size(ui->screen_line_10, 1, 90);
	lv_obj_set_scrollbar_mode(ui->screen_line_10, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_10_main_main_default
	static lv_style_t style_screen_line_10_main_main_default;
	if (style_screen_line_10_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_10_main_main_default);
	else
		lv_style_init(&style_screen_line_10_main_main_default);
	lv_style_set_line_color(&style_screen_line_10_main_main_default, lv_color_make(0x40, 0x71, 0x89));
	lv_style_set_line_width(&style_screen_line_10_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_10_main_main_default, true);
	lv_obj_add_style(ui->screen_line_10, &style_screen_line_10_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_10[] ={{0, 0},{0, 140},};
	lv_line_set_points(ui->screen_line_10,screen_line_10,2);

	//Write codes screen_line_11
	ui->screen_line_11 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_11, 154, 130);
	lv_obj_set_size(ui->screen_line_11, 1, 90);
	lv_obj_set_scrollbar_mode(ui->screen_line_11, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_11_main_main_default
	static lv_style_t style_screen_line_11_main_main_default;
	if (style_screen_line_11_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_11_main_main_default);
	else
		lv_style_init(&style_screen_line_11_main_main_default);
	lv_style_set_line_color(&style_screen_line_11_main_main_default, lv_color_make(0x40, 0x71, 0x89));
	lv_style_set_line_width(&style_screen_line_11_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_11_main_main_default, true);
	lv_obj_add_style(ui->screen_line_11, &style_screen_line_11_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_11[] ={{0, 0},{0, 140},};
	lv_line_set_points(ui->screen_line_11,screen_line_11,2);

	//Write codes screen_line_9
	ui->screen_line_9 = lv_line_create(ui->screen);
	lv_obj_set_pos(ui->screen_line_9, 215, 130);
	lv_obj_set_size(ui->screen_line_9, 1, 90);
	lv_obj_set_scrollbar_mode(ui->screen_line_9, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_line_9_main_main_default
	static lv_style_t style_screen_line_9_main_main_default;
	if (style_screen_line_9_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_line_9_main_main_default);
	else
		lv_style_init(&style_screen_line_9_main_main_default);
	lv_style_set_line_color(&style_screen_line_9_main_main_default, lv_color_make(0x40, 0x71, 0x89));
	lv_style_set_line_width(&style_screen_line_9_main_main_default, 1);
	lv_style_set_line_rounded(&style_screen_line_9_main_main_default, true);
	lv_obj_add_style(ui->screen_line_9, &style_screen_line_9_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	static lv_point_t screen_line_9[] ={{0, 0},{0, 140},};
	lv_line_set_points(ui->screen_line_9,screen_line_9,2);

	//Write codes screen_img_4
	ui->screen_img_4 = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_4, 10, 45);
	lv_obj_set_size(ui->screen_img_4, 25, 25);
	lv_obj_set_scrollbar_mode(ui->screen_img_4, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_4_main_main_default
	static lv_style_t style_screen_img_4_main_main_default;
	if (style_screen_img_4_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_img_4_main_main_default);
	else
		lv_style_init(&style_screen_img_4_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_4_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_4_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_4_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_4, &style_screen_img_4_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_4, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_4,&_temperature_25x25);
	lv_img_set_pivot(ui->screen_img_4, 50,50);
	lv_img_set_angle(ui->screen_img_4, 0);

	//Write codes screen_img_5
	ui->screen_img_5 = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_5, 126, 45);
	lv_obj_set_size(ui->screen_img_5, 25, 25);
	lv_obj_set_scrollbar_mode(ui->screen_img_5, LV_SCROLLBAR_MODE_OFF);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_5_main_main_default
	static lv_style_t style_screen_img_5_main_main_default;
	if (style_screen_img_5_main_main_default.prop_cnt > 1)
		lv_style_reset(&style_screen_img_5_main_main_default);
	else
		lv_style_init(&style_screen_img_5_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_5_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_5_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_5_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_5, &style_screen_img_5_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_5, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_5,&_hygro_25x25);
	lv_img_set_pivot(ui->screen_img_5, 50,50);
	lv_img_set_angle(ui->screen_img_5, 0);
}

//############################################################################################################
//
//############################################################################################################
static void chart_sht30_draw_event_cb(lv_event_t * e)
{
    lv_obj_t * obj = lv_event_get_target(e);

    /*Add the faded area before the lines are drawn*/
    lv_obj_draw_part_dsc_t * dsc = lv_event_get_draw_part_dsc(e);
    if(dsc->part == LV_PART_ITEMS) {
        if(!dsc->p1 || !dsc->p2) return;

        /*Add a line mask that keeps the area below the line*/
        lv_draw_mask_line_param_t line_mask_param;
        lv_draw_mask_line_points_init(&line_mask_param, dsc->p1->x, dsc->p1->y, dsc->p2->x, dsc->p2->y, LV_DRAW_MASK_LINE_SIDE_BOTTOM);
        int16_t line_mask_id = lv_draw_mask_add(&line_mask_param, NULL);

        /*Add a fade effect: transparent bottom covering top*/
        lv_coord_t h = lv_obj_get_height(obj);
        lv_draw_mask_fade_param_t fade_mask_param;
        lv_draw_mask_fade_init(&fade_mask_param, &obj->coords, LV_OPA_COVER, obj->coords.y1 + h / 8, LV_OPA_TRANSP,obj->coords.y2);
        int16_t fade_mask_id = lv_draw_mask_add(&fade_mask_param, NULL);

        /*Draw a rectangle that will be affected by the mask*/
        lv_draw_rect_dsc_t draw_rect_dsc;
        lv_draw_rect_dsc_init(&draw_rect_dsc);
        draw_rect_dsc.bg_opa = LV_OPA_40;
        draw_rect_dsc.bg_color = dsc->line_dsc->color;

        lv_area_t a;
        a.x1 = dsc->p1->x;
        a.x2 = dsc->p2->x - 1;
        a.y1 = LV_MIN(dsc->p1->y, dsc->p2->y);
        a.y2 = obj->coords.y2;
        lv_draw_rect(dsc->draw_ctx, &draw_rect_dsc, &a);

        /*Remove the masks*/
        lv_draw_mask_free_param(&line_mask_param);
        lv_draw_mask_free_param(&fade_mask_param);
        lv_draw_mask_remove_id(line_mask_id);
        lv_draw_mask_remove_id(fade_mask_id);
    }
}

//############################################################################################################
//
//############################################################################################################
void lvgl_sht30_add_data(lv_timer_t * timer){
  const uint8_t tempData[]={42,43,43,43, 44,44,45,45, 50,50,50,50, 46,46,47,48, 70,77,70,70, 48,47,46,45,
                            42,43,43,43, 70,77,70,70, 40,40,40,39, 60,60,67,60, 38,38,39,39, 50,50,50,50};
  
  const uint8_t humiData[]={80,80,80,80, 71,70,70,70, 44,44,45,45, 85,85,85,58, 50,50,50,50, 70,77,70,70, 
                            70,77,70,70, 60,60,67,60, 60,60,67,60, 40,40,40,39, 71,70,70,70, 48,47,46,45};

  lv_chart_set_next_value(chart_sht30, chart_sht30_temp_ser, tempData[charIdx]); 
  lv_chart_set_next_value(chart_sht30, chart_sht30_humi_ser, humiData[charIdx]); 
  if(++charIdx==CHART_POINT_COUNT)charIdx=0;
}

//############################################################################################################
//
//############################################################################################################
void lvgl_chart_sht30_init(){
  chart_sht30 = lv_chart_create(guider_ui.screen);
  lv_obj_set_pos(chart_sht30, 30, 130);
  lv_obj_set_size(chart_sht30, 190, 90);

  //Write style state: LV_STATE_DEFAULT for style_screen_chart_1_main_main_default
  static lv_style_t style_screen_chart_1_main_main_default;
  if (style_screen_chart_1_main_main_default.prop_cnt > 1)
  	lv_style_reset(&style_screen_chart_1_main_main_default);
  else
    lv_style_init(&style_screen_chart_1_main_main_default);
  lv_style_set_radius(&style_screen_chart_1_main_main_default, 0);
  lv_style_set_bg_color(&style_screen_chart_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
  lv_style_set_bg_grad_color(&style_screen_chart_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
  lv_style_set_bg_grad_dir(&style_screen_chart_1_main_main_default, LV_GRAD_DIR_NONE);
  lv_style_set_bg_opa(&style_screen_chart_1_main_main_default, 0);
  lv_style_set_shadow_width(&style_screen_chart_1_main_main_default, 0);
  lv_style_set_shadow_color(&style_screen_chart_1_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
  lv_style_set_shadow_opa(&style_screen_chart_1_main_main_default, 255);
  lv_style_set_shadow_spread(&style_screen_chart_1_main_main_default, 0);
  lv_style_set_shadow_ofs_x(&style_screen_chart_1_main_main_default, 0);
  lv_style_set_shadow_ofs_y(&style_screen_chart_1_main_main_default, 0);
  lv_style_set_border_color(&style_screen_chart_1_main_main_default, lv_color_make(0xe8, 0xe8, 0xe8));
  lv_style_set_border_width(&style_screen_chart_1_main_main_default, 0);
  lv_style_set_border_opa(&style_screen_chart_1_main_main_default, 255);
  lv_style_set_line_color(&style_screen_chart_1_main_main_default, lv_color_make(0xe8, 0xe8, 0xe8));
  lv_style_set_line_width(&style_screen_chart_1_main_main_default, 2);
  lv_style_set_line_opa(&style_screen_chart_1_main_main_default, 255);
  lv_obj_add_style(chart_sht30, &style_screen_chart_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

  lv_chart_set_type(chart_sht30, LV_CHART_TYPE_LINE);   /*Show lines and points too*/ 
  lv_obj_set_style_size(chart_sht30, 0, LV_PART_INDICATOR);   /*Do not display points on the data*/
  lv_obj_add_event_cb(chart_sht30, chart_sht30_draw_event_cb, LV_EVENT_DRAW_PART_BEGIN, NULL);

  lv_chart_set_div_line_count(chart_sht30, 0, 0);//remove division line
  lv_chart_set_update_mode(chart_sht30, LV_CHART_UPDATE_MODE_SHIFT);  
  lv_chart_set_point_count(chart_sht30, CHART_POINT_COUNT); 

  /*Add two data series*/
  chart_sht30_temp_ser = lv_chart_add_series(chart_sht30, lv_color_make(255, 255, 0), LV_CHART_AXIS_PRIMARY_Y);
  chart_sht30_humi_ser = lv_chart_add_series(chart_sht30, lv_color_make(0x21, 0x95, 0xf6), LV_CHART_AXIS_PRIMARY_Y);
}

